# tazza
TazZA - Organic Food HTML5 Template that perfectly designed for all kinds of organic farming business and Organic stores, including organic food, organic fruits, and vegetables, organic farm, agricultural company or basically everything related to an eco-friendly lifestyle.
